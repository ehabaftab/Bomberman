package demolition;

import processing.core.PImage; 
import processing.core.PApplet; 

/**
finishing tile
*/
public class Goal extends GameObject {

    /**
    Constructor
     */
    public Goal(int x, int y, PImage sprite) {
        super(x, y, sprite);
    }

    public void tick() {}
}