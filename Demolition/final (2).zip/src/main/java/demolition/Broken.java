package demolition;

import processing.core.PImage; 
import processing.core.PApplet; 

/**
broken walls
*/
public class Broken extends GameObject {

    /**
    Constructor
     */
    public Broken(int x, int y, PImage sprite) {
        super(x, y, sprite);
    }

    public void tick() {}
}